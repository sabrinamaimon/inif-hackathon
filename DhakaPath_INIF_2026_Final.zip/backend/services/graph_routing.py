import networkx as nx
from typing import List, Dict, Any, Optional, Tuple
from data.dhaka_transit_data import DHAKA_HUBS, TRANSIT_ROUTES, TRANSIT_EDGES
from services.fare_engine import DhakaFareEngine
from models.schemas import RouteOption, RouteLeg

class DhakaTransitGraph:
    """
    Multi-modal graph for Dhaka city transit.
    Uses NetworkX MultiDiGraph to preserve Metro, Bus, Leguna, and Rickshaw edges.
    Supports dynamic disruption weights, detour calculations, and multi-leg generation.
    """

    def __init__(self):
        self.multi_graph = nx.MultiDiGraph()
        self.build_base_graph()

    def build_base_graph(self):
        self.multi_graph.clear()
        for hub_name, hub_data in DHAKA_HUBS.items():
            self.multi_graph.add_node(
                hub_name,
                name_bn=hub_data["name_bn"],
                lat=hub_data["lat"],
                lng=hub_data["lng"],
                is_metro=hub_data["is_metro_station"]
            )

        # 1. Add Metro Edges (MRT-6) - All 17 official consecutive stations
        mrt_stops = [
            "Uttara North", "Uttara Center", "Uttara South", "Pallabi",
            "Mirpur 11", "Mirpur 10", "Kazipara", "Shewrapara",
            "Agargaon", "Bijoy Sarani", "Farmgate", "Karwan Bazar",
            "Shahbagh", "Dhaka University", "Bangladesh Secretariat",
            "Motijheel", "Kamalapur"
        ]
        for i in range(len(mrt_stops) - 1):
            u, v = mrt_stops[i], mrt_stops[i+1]
            dist = self._get_edge_distance(u, v)
            base_time = max(2, int(round(dist * 1.8)))
            # Metro is immune to street traffic/waterlogging!
            self.multi_graph.add_edge(
                u, v,
                key="metro",
                mode="metro",
                line_name="MRT-6 Metro Rail",
                distance_km=dist,
                base_time_mins=base_time,
                operator="DMTCL",
                color="#059669",
                student_allowed=False,
                elevated=True
            )
            self.multi_graph.add_edge(
                v, u,
                key="metro",
                mode="metro",
                line_name="MRT-6 Metro Rail",
                distance_km=dist,
                base_time_mins=base_time,
                operator="DMTCL",
                color="#059669",
                student_allowed=False,
                elevated=True
            )

        # Connector between bus terminal Uttara and Uttara North metro station
        if "Uttara" in self.multi_graph and "Uttara North" in self.multi_graph:
            self.multi_graph.add_edge("Uttara", "Uttara North", key="walk", mode="rickshaw", line_name="Metro Link Walk", distance_km=0.2, base_time_mins=2, operator="Walk / Connector", color="#059669", student_allowed=True, elevated=False)
            self.multi_graph.add_edge("Uttara North", "Uttara", key="walk", mode="rickshaw", line_name="Metro Link Walk", distance_km=0.2, base_time_mins=2, operator="Walk / Connector", color="#059669", student_allowed=True, elevated=False)

        # 2. Add Bus Routes
        for route in TRANSIT_ROUTES:
            if route["type"] != "bus":
                continue
            stops = route["hubs"]
            for i in range(len(stops) - 1):
                u, v = stops[i], stops[i+1]
                dist = self._get_edge_distance(u, v)
                base_time = self._get_edge_time(u, v)
                self.multi_graph.add_edge(
                    u, v,
                    key=f"bus_{route['name']}",
                    mode="bus",
                    line_name=route["name"],
                    distance_km=dist,
                    base_time_mins=base_time,
                    operator=route["operator"],
                    color=route["color"],
                    student_allowed=True,
                    elevated=False
                )
                self.multi_graph.add_edge(
                    v, u,
                    key=f"bus_{route['name']}",
                    mode="bus",
                    line_name=route["name"],
                    distance_km=dist,
                    base_time_mins=base_time,
                    operator=route["operator"],
                    color=route["color"],
                    student_allowed=True,
                    elevated=False
                )

        # 3. Add Leguna Routes
        for route in TRANSIT_ROUTES:
            if route["type"] != "leguna":
                continue
            stops = route["hubs"]
            for i in range(len(stops) - 1):
                u, v = stops[i], stops[i+1]
                dist = self._get_edge_distance(u, v)
                base_time = max(5, int(dist * 3.5))
                self.multi_graph.add_edge(
                    u, v,
                    key=f"leguna_{route['name']}",
                    mode="leguna",
                    line_name=route["name"],
                    distance_km=dist,
                    base_time_mins=base_time,
                    operator="Leguna Co-op",
                    color=route["color"],
                    student_allowed=False,
                    elevated=False
                )
                self.multi_graph.add_edge(
                    v, u,
                    key=f"leguna_{route['name']}",
                    mode="leguna",
                    line_name=route["name"],
                    distance_km=dist,
                    base_time_mins=base_time,
                    operator="Leguna Co-op",
                    color=route["color"],
                    student_allowed=False,
                    elevated=False
                )

        # 4. Add Connector Rickshaw Edges between adjacent hubs
        for (u, v), edge_info in TRANSIT_EDGES.items():
            dist = edge_info["distance_km"]
            base_time = edge_info["base_time_mins"]
            self.multi_graph.add_edge(
                u, v,
                key="rickshaw",
                mode="rickshaw",
                line_name="Connector Rickshaw",
                distance_km=dist,
                base_time_mins=base_time,
                operator="Local Rickshaw Puller",
                color="#eab308",
                student_allowed=False,
                elevated=False
            )
            self.multi_graph.add_edge(
                v, u,
                key="rickshaw",
                mode="rickshaw",
                line_name="Connector Rickshaw",
                distance_km=dist,
                base_time_mins=base_time,
                operator="Local Rickshaw Puller",
                color="#eab308",
                student_allowed=False,
                elevated=False
            )

    def _get_edge_distance(self, u: str, v: str) -> float:
        if (u, v) in TRANSIT_EDGES:
            return TRANSIT_EDGES[(u, v)]["distance_km"]
        if (v, u) in TRANSIT_EDGES:
            return TRANSIT_EDGES[(v, u)]["distance_km"]
        return 3.0

    def _get_edge_time(self, u: str, v: str) -> int:
        if (u, v) in TRANSIT_EDGES:
            return TRANSIT_EDGES[(u, v)]["base_time_mins"]
        if (v, u) in TRANSIT_EDGES:
            return TRANSIT_EDGES[(v, u)]["base_time_mins"]
        return 12

    def find_routes(
        self,
        origin: str,
        destination: str,
        passenger_type: str = "general",
        avoid_hubs: List[str] = [],
        weather: str = "normal",
        is_rush_hour: bool = False,
        active_alerts: List[Dict[str, Any]] = []
    ) -> List[RouteOption]:
        """Generates ranked multimodal routes with disruption rerouting"""
        if origin not in DHAKA_HUBS or destination not in DHAKA_HUBS or origin == destination:
            return []

        # Identify blocked or disrupted hubs
        blocked_set = set(avoid_hubs)
        waterlogged_set = set()

        for alert in active_alerts:
            if not alert.get("is_active", True):
                continue
            hub = alert.get("hub")
            alert_type = alert.get("type")
            if alert_type in ["blockade", "protest"]:
                blocked_set.add(hub)
            elif alert_type == "waterlogging":
                waterlogged_set.add(hub)

        # Generate up to 4 diverse route paths
        routes: List[RouteOption] = []

        # 1. Metro / Fastest Priority
        fast_option = self._generate_path(
            origin, destination,
            priority="fastest",
            weather=weather,
            is_rush_hour=is_rush_hour,
            waterlogged_hubs=waterlogged_set,
            blocked_hubs=blocked_set
        )
        if fast_option:
            fast_option.id = "opt-fastest"
            fast_option.type_badge = "Fastest Route"
            fast_option.type_badge_bn = "১০০% বাধামুক্ত ও দ্রুততম"
            fast_option.title = f"Express Priority ({origin} -> {destination})"
            fast_option.title_bn = f"দ্রুততম রুট ({DHAKA_HUBS[origin]['name_bn']} -> {DHAKA_HUBS[destination]['name_bn']})"
            fast_option.obstacles_badge = "🟢 Clear Overhead Route"
            fast_option.obstacles_badge_bn = "🟢 বাধামুক্ত উড়ালপথ (০% যানজট ও জলজট)"
            fast_option.is_recommended = True
            routes.append(fast_option)

        # 2. Student / Cheapest Priority (Bus focus)
        bus_option = self._generate_path(
            origin, destination,
            priority="cheapest_bus",
            weather=weather,
            is_rush_hour=is_rush_hour,
            waterlogged_hubs=waterlogged_set,
            blocked_hubs=blocked_set
        )
        if bus_option:
            # Only add if distinct from fastest
            is_distinct = (
                not routes or
                bus_option.total_regular_fare != routes[0].total_regular_fare or
                bus_option.transfers != routes[0].transfers or
                [l.mode for l in bus_option.legs] != [l.mode for l in routes[0].legs]
            )
            if is_distinct:
                bus_option.id = "opt-cheapest"
                bus_option.type_badge = "Student & Budget Pick"
                bus_option.type_badge_bn = "সবচেয়ে সাশ্রয়ী ও হাফ-পাস"
                bus_option.title = f"Economy Bus Route ({origin} -> {destination})"
                bus_option.title_bn = f"সাশ্রয়ী ও হাফ-পাস বাস রুট ({DHAKA_HUBS[origin]['name_bn']} -> {DHAKA_HUBS[destination]['name_bn']})"
                bus_option.obstacles_badge = "🟡 Surface Road Traffic"
                bus_option.obstacles_badge_bn = "🟡 সাধারণ সড়ক ট্রাফিক"
                routes.append(bus_option)

        # 3. Resilient Detour Route if disruptions active
        if waterlogged_set or blocked_set:
            detour_option = self._generate_path(
                origin, destination,
                priority="detour",
                weather=weather,
                is_rush_hour=is_rush_hour,
                waterlogged_hubs=waterlogged_set,
                blocked_hubs=blocked_set
            )
            if detour_option and not any(r.legs == detour_option.legs for r in routes):
                detour_option.id = "opt-detour"
                detour_option.type_badge = "Safe Detour"
                detour_option.type_badge_bn = "নিরাপদ বিকল্প পথ"
                detour_option.title = "Disruption Bypass Detour"
                detour_option.title_bn = "জলজট ও ব্যারিকেড এড়িয়ে বিকল্প পথ"
                detour_option.obstacles_badge = "🟢 Detour around Obstacle"
                detour_option.obstacles_badge_bn = "🟢 বাধা এড়িয়ে বিকল্প পথ"
                detour_option.is_detour = True
                detour_option.disruption_warning = "Bypassing waterlogged/blocked intersections automatically."
                routes.append(detour_option)

        # Fallback if no specific paths found
        if not routes:
            direct_fallback = self._generate_direct_fallback(origin, destination, weather, is_rush_hour)
            if direct_fallback:
                routes.append(direct_fallback)

        # Estimate base distance
        est_distance = 5.0
        if routes and routes[0].legs:
            est_distance = sum(leg.distance_km for leg in routes[0].legs)
        else:
            est_distance = self._get_edge_distance(origin, destination)

        # Enrich existing routes with distance and obstacle badges
        for r in routes:
            metro_dist = sum(l.distance_km for l in r.legs if l.mode == "metro")
            total_leg_dist = sum(l.distance_km for l in r.legs) if r.legs else est_distance
            r.total_distance_km = round(total_leg_dist, 1)
            
            # Strict mode definition: only call it metro if at least 70% of journey or both origin & dest are metro
            is_orig_metro = DHAKA_HUBS.get(origin, {}).get("is_metro_station", False)
            is_dest_metro = DHAKA_HUBS.get(destination, {}).get("is_metro_station", False)
            if (metro_dist / max(0.1, total_leg_dist) >= 0.7) or (is_orig_metro and is_dest_metro):
                r.mode = "metro"
                r.obstacles_badge = "🟢 বাধামুক্ত উড়ালপথ (০% যানজট ও জলজট)"
                r.obstacles_status = "safe"
            else:
                r.mode = "bus"
                r.obstacles_badge = "🔴 সড়কে বৃষ্টির জলজট" if weather in ["rain", "heavy_monsoon"] else ("🟡 পিক আওয়ার ট্রাফিক" if is_rush_hour else "🟡 সাধারণ সড়ক ট্রাফিক")
                r.obstacles_status = "warning" if (is_rush_hour or weather in ["rain", "heavy_monsoon"]) else "traffic"

        # 4. Direct CNG Auto-Rickshaw Option
        cng_fare, _, cng_surge = DhakaFareEngine.calculate_cng_fare(est_distance, weather=weather, is_rush_hour=is_rush_hour)
        cng_time = max(14, int(round(est_distance * 2.3)))
        if is_rush_hour:
            cng_time = int(cng_time * 1.25)
        if weather in ["rain", "heavy_monsoon"]:
            cng_time = int(cng_time * 1.2)

        cng_route = RouteOption(
            id="opt-cng",
            mode="cng",
            title=f"Direct CNG Auto-Rickshaw ({origin} -> {destination})",
            title_bn=f"সরাসরি সিএনজি অটোরিকশা ({DHAKA_HUBS[origin]['name_bn']} -> {DHAKA_HUBS[destination]['name_bn']})",
            type_badge="Personal Metered Transit",
            type_badge_bn="ব্যক্তিগত মিটার বাহন",
            total_duration_mins=cng_time,
            total_regular_fare=cng_fare,
            total_student_fare=cng_fare,
            total_distance_km=round(est_distance, 1),
            obstacles_badge="🟡 Moderate Traffic, Alley Accessible",
            obstacles_badge_bn="🟡 মাঝারি ট্রাফিক, অলিগলি ব্যবহারের সুবিধা",
            obstacles_status="traffic",
            transfers=0,
            is_recommended=False,
            is_detour=False,
            legs=[
                RouteLeg(
                    leg_number=1,
                    mode="cng",
                    line_name="CNG Auto-Rickshaw (Metered)",
                    line_name_bn="সিএনজি অটোরিকশা (মিটার)",
                    from_hub=origin,
                    to_hub=destination,
                    distance_km=round(est_distance, 1),
                    duration_mins=cng_time,
                    regular_fare_bdt=cng_fare,
                    student_fare_bdt=cng_fare,
                    surge_multiplier=cng_surge,
                    landmark_instructions=f"Direct CNG from {origin} to {destination}. No transfers required.",
                    landmark_instructions_bn=f"{origin} সিএনজি স্ট্যান্ড থেকে সরাসরি {destination}। কোনো পরিবর্তন ছাড়া দ্রুত যাতায়াত।"
                )
            ]
        )
        routes.append(cng_route)

        # 5. Ride-Share Bike Option (Pathao / Uber Moto)
        bike_time = max(9, int(round(est_distance * 1.6)))
        if is_rush_hour:
            bike_time = int(bike_time * 1.15)
        raw_bike = 30 + (est_distance - 1) * 12 * (1.2 if weather in ["rain", "heavy_monsoon"] else 1.0)
        bike_base = max(35, int(round(raw_bike / 5.0) * 5))
        bike_obstacles_en = "🌧️ Slippery Road - Ride Cautiously" if weather in ["rain", "heavy_monsoon"] else "🟢 Quick Maneuver through Traffic"
        bike_obstacles_bn = "🌧️ বৃষ্টিতে পিচ্ছিল সড়ক ও সতর্ক রাইড" if weather in ["rain", "heavy_monsoon"] else "🟢 জ্যামের ফাঁক দিয়ে দ্রুত বের হওয়ার সুযোগ"

        bike_route = RouteOption(
            id="opt-bike",
            mode="bike",
            title=f"Ride-Share Motorbike ({origin} -> {destination})",
            title_bn=f"মোটরসাইকেল রাইডশেয়ার ({DHAKA_HUBS[origin]['name_bn']} -> {DHAKA_HUBS[destination]['name_bn']})",
            type_badge="Fastest Surface Transit",
            type_badge_bn="সড়কপথে দ্রুততম",
            total_duration_mins=bike_time,
            total_regular_fare=bike_base,
            total_student_fare=bike_base,
            total_distance_km=round(est_distance, 1),
            obstacles_badge=bike_obstacles_en,
            obstacles_badge_bn=bike_obstacles_bn,
            obstacles_status="warning" if weather in ["rain", "heavy_monsoon"] else "safe",
            transfers=0,
            is_recommended=False,
            is_detour=False,
            legs=[
                RouteLeg(
                    leg_number=1,
                    mode="bike",
                    line_name="Motorcycle Ride-Share (Pathao or Uber)",
                    line_name_bn="মোটরসাইকেল রাইডশেয়ার (পাঠাও ও উবার)",
                    from_hub=origin,
                    to_hub=destination,
                    distance_km=round(est_distance, 1),
                    duration_mins=bike_time,
                    regular_fare_bdt=bike_base,
                    student_fare_bdt=bike_base,
                    surge_multiplier=1.0,
                    landmark_instructions=f"1-on-1 motorbike pickup at {origin}. Direct commute to {destination}.",
                    landmark_instructions_bn=f"{DHAKA_HUBS[origin]['name_bn']} থেকে বাইক রাইডশেয়ারে সরাসরি {DHAKA_HUBS[destination]['name_bn']}।"
                )
            ]
        )
        routes.append(bike_route)

        # 6. Private Car / Cab Option
        car_time = max(16, int(round(est_distance * 2.6)))
        if is_rush_hour:
            car_time = int(car_time * 1.4)
        if weather in ["rain", "heavy_monsoon"]:
            car_time = int(car_time * 1.25)
        raw_car = 100 + (est_distance - 1) * 24 * (1.2 if is_rush_hour else 1.0)
        car_fare = max(140, int(round(raw_car / 10.0) * 10))
        car_obstacles_en = "🔴 Peak Hour Traffic Likely" if is_rush_hour else "🟡 Normal Surface Traffic (AC & Comfort)"
        car_obstacles_bn = "🔴 পিক-আওয়ারে প্রধান সড়কে যানজটের সম্ভাবনা" if is_rush_hour else "🟡 স্বাভাবিক সড়ক ট্রাফিক (এসি ও আরামদায়ক)"

        car_route = RouteOption(
            id="opt-car",
            mode="car",
            title=f"Private Car ({origin} -> {destination})",
            title_bn=f"প্রাইভেট কার ক্যাব ({DHAKA_HUBS[origin]['name_bn']} -> {DHAKA_HUBS[destination]['name_bn']})",
            type_badge="Comfortable & AC",
            type_badge_bn="আরামদায়ক ও এসি",
            total_duration_mins=car_time,
            total_regular_fare=car_fare,
            total_student_fare=car_fare,
            total_distance_km=round(est_distance * 1.06, 1),
            obstacles_badge=car_obstacles_en,
            obstacles_badge_bn=car_obstacles_bn,
            obstacles_status="warning" if is_rush_hour else "traffic",
            transfers=0,
            is_recommended=False,
            is_detour=False,
            legs=[
                RouteLeg(
                    leg_number=1,
                    mode="car",
                    line_name="Private Cab and Car",
                    line_name_bn="প্রাইভেট ক্যাব ও কার",
                    from_hub=origin,
                    to_hub=destination,
                    distance_km=round(est_distance * 1.06, 1),
                    duration_mins=car_time,
                    regular_fare_bdt=car_fare,
                    student_fare_bdt=car_fare,
                    surge_multiplier=1.0,
                    landmark_instructions=f"Door-to-door AC car pickup from {origin} to {destination}.",
                    landmark_instructions_bn=f"{DHAKA_HUBS[origin]['name_bn']} থেকে ডোর-টু-ডোর এসি কার ক্যাবে সরাসরি {DHAKA_HUBS[destination]['name_bn']}।"
                )
            ]
        )
        routes.append(car_route)

        # 7. Rickshaw Option (for shorter trips <= 6.5 km)
        if est_distance <= 6.5:
            raw_rickshaw = est_distance * 22 * (1.4 if weather in ["rain", "heavy_monsoon"] else 1.0)
            rickshaw_fare = max(30, int(round(raw_rickshaw / 5.0) * 5))
            rickshaw_time = max(10, int(round(est_distance * 5.2)))
            rickshaw_route = RouteOption(
                id="opt-rickshaw",
                mode="rickshaw",
                title=f"Traditional Rickshaw ({origin} -> {destination})",
                title_bn=f"ঐতিহ্যবাহী রিকশা ({DHAKA_HUBS[origin]['name_bn']} -> {DHAKA_HUBS[destination]['name_bn']})",
                type_badge="Local Feeder Transit",
                type_badge_bn="লোকাল ও গলিপথ",
                total_duration_mins=rickshaw_time,
                total_regular_fare=rickshaw_fare,
                total_student_fare=rickshaw_fare,
                total_distance_km=round(est_distance, 1),
                obstacles_badge="🟢 Easy Passage via Alleyways",
                obstacles_badge_bn="🟢 অভ্যন্তরীণ অলিগলিতে বাধাহীন চলাচল",
                obstacles_status="safe",
                transfers=0,
                is_recommended=False,
                is_detour=False,
                legs=[
                    RouteLeg(
                        leg_number=1,
                        mode="rickshaw",
                        line_name="Dhaka Traditional Rickshaw",
                        line_name_bn="ঢাকা ঐতিহ্যবাহী রিকশা",
                        from_hub=origin,
                        to_hub=destination,
                        distance_km=round(est_distance, 1),
                        duration_mins=rickshaw_time,
                        regular_fare_bdt=rickshaw_fare,
                        student_fare_bdt=rickshaw_fare,
                        surge_multiplier=1.0,
                        landmark_instructions=f"Hooded cycle rickshaw from {origin} through inner roads to {destination}.",
                        landmark_instructions_bn=f"{DHAKA_HUBS[origin]['name_bn']} থেকে হুড তোলা রিকশা নিয়ে গলিপথ দিয়ে নিরিবিলি {DHAKA_HUBS[destination]['name_bn']} যাতায়াত।"
                    )
                ]
            )
        # Reconcile exact sum of legs for fares and duration
        for r in routes:
            r.total_regular_fare = sum(l.regular_fare_bdt for l in r.legs)
            r.total_student_fare = sum(l.student_fare_bdt for l in r.legs)
            r.total_duration_mins = sum(l.duration_mins for l in r.legs) + (r.transfers * 3)

        return routes

    def _generate_path(
        self,
        origin: str,
        destination: str,
        priority: str,
        weather: str,
        is_rush_hour: bool,
        waterlogged_hubs: set,
        blocked_hubs: set
    ) -> Optional[RouteOption]:
        """Projects MultiDiGraph into a weighted DiGraph for specific priority and runs shortest path"""
        g = nx.DiGraph()
        for node, data in self.multi_graph.nodes(data=True):
            g.add_node(node, **data)

        # Project multi-edges into single best edge between (u, v) based on priority
        for u, v in self.multi_graph.edges():
            edge_dict = self.multi_graph[u][v]
            best_candidate = None
            best_weight = float('inf')

            for key, data in edge_dict.items():
                mode = data.get("mode", "bus")
                elevated = data.get("elevated", False)
                base_time = data.get("base_time_mins", 10)

                # If hub is blocked:
                # Surface transport cannot pass, but elevated Metro CAN pass
                if (u in blocked_hubs or v in blocked_hubs) and not elevated:
                    continue

                weight = base_time

                # Priority adjustments
                if priority == "fastest":
                    if mode == "metro":
                        weight = base_time * 0.4  # Rapid transit highest preference
                    elif mode == "bus":
                        weight = base_time * 1.0
                    elif mode == "rickshaw":
                        weight = base_time * 1.8
                elif priority == "cheapest_bus":
                    if mode == "bus":
                        weight = base_time * 0.5  # Student half-pass bus preferred
                    elif mode == "metro":
                        weight = base_time * 1.1
                    elif mode == "rickshaw":
                        weight = base_time * 2.5
                elif priority == "detour":
                    if (u in waterlogged_hubs or v in waterlogged_hubs) and not elevated:
                        weight = base_time * 5.0  # Avoid flooded streets
                    elif elevated:
                        weight = base_time * 0.3  # Prefer elevated metro for detour

                # Penalties for weather on surface
                if not elevated:
                    if (u in waterlogged_hubs or v in waterlogged_hubs):
                        weight += 15
                    if weather in ["rain", "heavy_monsoon"]:
                        weight *= 1.4
                    if is_rush_hour:
                        weight *= 1.3

                if weight < best_weight:
                    best_weight = weight
                    best_candidate = dict(data)
                    best_candidate["calc_weight"] = weight

            if best_candidate:
                g.add_edge(u, v, **best_candidate)

        try:
            node_path = nx.shortest_path(g, source=origin, target=destination, weight="calc_weight")
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            return None

        if not node_path or len(node_path) < 2:
            return None

        # Build RouteLeg list - Consolidate continuous legs of same transit line
        raw_segments = []
        for i in range(len(node_path) - 1):
            u = node_path[i]
            v = node_path[i+1]
            edge_data = g.get_edge_data(u, v) or {}
            mode = edge_data.get("mode", "bus")
            line_name = edge_data.get("line_name", "Transit Line")
            dist = edge_data.get("distance_km", 2.5)
            duration = edge_data.get("base_time_mins", 10)

            # Adjust duration for weather and rush hour on surface transport
            if mode != "metro":
                if weather in ["rain", "heavy_monsoon"]:
                    duration = int(duration * 1.4)
                if is_rush_hour:
                    duration = int(duration * 1.3)
                if u in waterlogged_hubs or v in waterlogged_hubs:
                    duration += 15

            raw_segments.append({
                "u": u,
                "v": v,
                "mode": mode,
                "line_name": line_name,
                "dist": dist,
                "duration": duration,
                "is_affected": (u in waterlogged_hubs or v in waterlogged_hubs or u in blocked_hubs or v in blocked_hubs)
            })

        consolidated = []
        for seg in raw_segments:
            if consolidated and consolidated[-1]["mode"] == seg["mode"] and consolidated[-1]["line_name"] == seg["line_name"]:
                consolidated[-1]["to_hub"] = seg["v"]
                consolidated[-1]["distance_km"] += seg["dist"]
                consolidated[-1]["duration_mins"] += seg["duration"]
                consolidated[-1]["intermediate_stops"].append(seg["u"])
                if seg["is_affected"]:
                    consolidated[-1]["is_affected"] = True
            else:
                consolidated.append({
                    "from_hub": seg["u"],
                    "to_hub": seg["v"],
                    "mode": seg["mode"],
                    "line_name": seg["line_name"],
                    "distance_km": seg["dist"],
                    "duration_mins": seg["duration"],
                    "intermediate_stops": [],
                    "is_affected": seg["is_affected"]
                })

        legs: List[RouteLeg] = []
        total_time = 0
        total_regular = 0
        total_student = 0
        transfers = max(0, len(consolidated) - 1)

        for i, c in enumerate(consolidated):
            u = c["from_hub"]
            v = c["to_hub"]
            mode = c["mode"]
            line_name = c["line_name"]
            dist = c["distance_km"]
            duration = c["duration_mins"]

            # Calculate exact leg fare
            surge_mult = 1.0
            if mode == "metro":
                reg_fare = DhakaFareEngine.calculate_metro_fare(u, v) or 20
                stud_fare = reg_fare  # Metro has no student discount
            elif mode == "bus":
                reg_fare, stud_fare = DhakaFareEngine.calculate_bus_fare(dist, from_hub=u, to_hub=v)
            elif mode == "leguna":
                reg_fare, stud_fare = DhakaFareEngine.calculate_leguna_fare(u, v, dist)
            else:  # rickshaw
                reg_fare, stud_fare, surge_mult = DhakaFareEngine.calculate_rickshaw_fare(
                    u, v, dist, weather=weather, is_rush_hour=is_rush_hour
                )

            instructions = self._get_landmark_instruction(u, v, mode, line_name)
            if c["intermediate_stops"]:
                instructions += f" ({len(c['intermediate_stops'])} intermediate stops via {', '.join(c['intermediate_stops'][:3])}{'...' if len(c['intermediate_stops']) > 3 else ''})"

            leg = RouteLeg(
                leg_number=i+1,
                mode=mode,
                line_name=line_name,
                from_hub=u,
                to_hub=v,
                distance_km=round(dist, 1),
                duration_mins=duration,
                regular_fare_bdt=reg_fare,
                student_fare_bdt=stud_fare,
                surge_multiplier=surge_mult,
                landmark_instructions=instructions,
                is_affected_by_alert=c["is_affected"]
            )
            legs.append(leg)
            total_time += duration
            total_regular += reg_fare
            total_student += stud_fare

        title_via = node_path[1] if len(node_path) > 2 else 'Direct'
        title_bn_via = f"রুট: {DHAKA_HUBS.get(node_path[1], {}).get('name_bn', '')} হয়ে" if len(node_path) > 2 else "সরাসরি ট্রানজিট রুট"

        return RouteOption(
            id=f"opt-{priority}",
            title=f"Route via {title_via}",
            title_bn=title_bn_via,
            type_badge="Standard",
            type_badge_bn="স্ট্যান্ডার্ড রুট",
            total_duration_mins=total_time,
            total_regular_fare=total_regular,
            total_student_fare=total_student,
            transfers=transfers,
            legs=legs,
            is_recommended=False,
            is_detour=False
        )

    def _get_landmark_instruction(self, u: str, v: str, mode: str, line_name: str) -> str:
        hub_u = DHAKA_HUBS.get(u, {})
        landmarks = hub_u.get("landmarks", ["Main junction"])
        primary_landmark = landmarks[0] if landmarks else "bus stand"

        if mode == "metro":
            return f"Board MRT-6 Train from {u} Station concourse. Alight at {v} Station platform."
        elif mode == "bus":
            return f"Board {line_name} at {u} near {primary_landmark}. Ride towards {v}."
        elif mode == "leguna":
            return f"Board leguna stand at {u} ({primary_landmark}). Ask driver for {v} drop-off."
        else:
            return f"Hail connector rickshaw near {primary_landmark} at {u}. Negotiate drop-off at {v}."

    def _generate_direct_fallback(self, origin: str, destination: str, weather: str, is_rush_hour: bool) -> RouteOption:
        dist = 5.0
        reg_fare, stud_fare, surge = DhakaFareEngine.calculate_rickshaw_fare(
            origin, destination, dist, weather=weather, is_rush_hour=is_rush_hour
        )
        leg = RouteLeg(
            leg_number=1,
            mode="rickshaw",
            line_name="Direct Connector Rickshaw/CNG",
            line_name_bn="সরাসরি কানেক্টর রিকশা বা সিএনজি",
            from_hub=origin,
            to_hub=destination,
            distance_km=dist,
            duration_mins=25,
            regular_fare_bdt=reg_fare,
            student_fare_bdt=stud_fare,
            surge_multiplier=surge,
            landmark_instructions=f"Take direct connector from {origin} to {destination}.",
            landmark_instructions_bn=f"{origin} থেকে সরাসরি কানেক্টর বাহন নিয়ে {destination} এ যান।"
        )
        return RouteOption(
            id="opt-fallback",
            title=f"Direct Connector ({origin} -> {destination})",
            title_bn=f"সরাসরি সংযোগ ({DHAKA_HUBS[origin]['name_bn']} -> {DHAKA_HUBS[destination]['name_bn']})",
            type_badge="Direct",
            type_badge_bn="সরাসরি সংযোগ",
            total_duration_mins=25,
            total_regular_fare=reg_fare,
            total_student_fare=stud_fare,
            transfers=0,
            legs=[leg],
            is_recommended=True,
            is_detour=False
        )
