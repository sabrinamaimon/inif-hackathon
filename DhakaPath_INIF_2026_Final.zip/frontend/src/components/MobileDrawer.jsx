'use client';

import React from 'react';
import Link from 'next/link';
import { X, Navigation, AlertTriangle, Cpu, Users, Bus, FileScan, ShieldAlert, Globe, Sun, Moon, Download, Map, Shield } from 'lucide-react';
import { I18N, toBnDigits } from '../utils/localization';

export default function MobileDrawer({ 
  isOpen, 
  onClose, 
  currentTab, 
  setCurrentTab, 
  lang, 
  setLang, 
  theme = 'dark',
  setTheme,
  activeAlertCount = 3,
  onOpenScanner,
  onDownloadPostcard
}) {
  if (!isOpen) return null;
  const t = I18N[lang] || I18N.bn;

  const menuItems = [
    { id: 'home', label: lang === 'bn' ? 'রুট প্ল্যানার' : 'Route Planner', icon: Navigation },
    { id: 'alerts', label: lang === 'bn' ? 'সড়ক বিঘ্ন' : 'Street Alerts', icon: AlertTriangle, badge: activeAlertCount },
    { id: 'simulator', label: lang === 'bn' ? 'ম্যাপ ও সিমুলেটর' : 'Map & Simulator', icon: Map },
    { id: 'cms', label: lang === 'bn' ? 'বাস রুট ডিরেক্টরি' : 'Bus Directory', icon: Bus, badge: 183 },
    { id: 'rideshare', label: lang === 'bn' ? 'রাইড শেয়ার' : 'Ride Share', icon: Users },
  ];

  const handleSelectTab = (tabId) => {
    setCurrentTab(tabId);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex lg:hidden">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-[#0a0705]/85 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* Slide-out Drawer */}
      <div className={`relative w-4/5 max-w-xs p-5 flex flex-col justify-between shadow-2xl h-full z-10 animate-in slide-in-from-left duration-300 font-anek ${
        theme === 'light'
          ? 'bg-white border-r-2 border-slate-200 text-slate-800'
          : 'bg-[#18130f] border-r-2 border-[#c69429]/50 text-[#dfcfb2]'
      }`}>
        <div>
          {/* Header */}
          <div className={`flex items-center justify-between pb-4 border-b ${
            theme === 'light' ? 'border-slate-200' : 'border-[#c69429]/30'
          }`}>
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl overflow-hidden border border-[#f6d16f] shadow-md shrink-0">
                <img 
                  src="/assets/dhakar_poth_logo.jpg" 
                  alt={t.brandName} 
                  className="w-full h-full object-cover object-center"
                />
              </div>
              <span className="font-rickshaw text-2xl font-bold rickshaw-brand-typography">{t.brandName}</span>
            </div>
            <button 
              onClick={onClose}
              className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                theme === 'light' ? 'bg-slate-100 text-slate-700 hover:text-black border-slate-300' : 'bg-[#292019] text-[#dfcfb2] hover:text-white border-[#c69429]/30'
              }`}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Nav Links */}
          <nav className="mt-5 space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleSelectTab(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
                    isActive 
                      ? 'bg-gradient-to-r from-[#b83a2e] to-[#891e17] text-[#fbf8f1] font-bold border border-[#f6d16f] shadow-md shadow-[#b83a2e]/30' 
                      : (theme === 'light' ? 'text-slate-700 hover:bg-slate-100 border border-transparent' : 'text-[#dfcfb2] hover:bg-[#292019] border border-transparent')
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 ${isActive ? (theme === 'light' ? 'text-white' : 'text-[#f6d16f]') : (theme === 'light' ? 'text-slate-500' : 'text-[#c69429]')}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && item.badge > 0 && (
                    <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-[#b83a2e] text-[#fbf8f1] border border-[#f6d16f] animate-pulse">
                      {lang === 'bn' ? toBnDigits(item.badge) : item.badge}
                    </span>
                  )}
                </button>
              );
            })}

            {/* Commute Card Download in Mobile Drawer */}
            <button
              onClick={() => { onClose(); onDownloadPostcard && onDownloadPostcard(); }}
              className="w-full mt-3 flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-bold bg-[#15453b]/40 border border-[#2a6f62] text-[#6ee7b7] hover:bg-[#15453b]/70 transition-all active:scale-95 shadow-md"
            >
              <div className="flex items-center gap-3">
                <Download className="w-4 h-4 text-[#6ee7b7]" />
                <span>{lang === 'bn' ? 'কমিউট কার্ড ডাউনলোড' : 'Download Commute Card'}</span>
              </div>
              <span className="text-[10px] font-mono font-bold text-[#f6d16f] bg-black/40 px-2 py-0.5 rounded border border-[#2a6f62]/50">PNG</span>
            </button>

            {/* Bonus Signboard OCR Button */}
            <button
              onClick={() => { onClose(); onOpenScanner(); }}
              className={`w-full mt-2 flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-semibold cursor-pointer ${
                theme === 'light' 
                  ? 'bg-amber-50 border border-amber-200 text-slate-900 hover:bg-amber-100' 
                  : 'bg-[#201712] border border-[#c69429]/40 text-[#f6d16f] hover:bg-[#2a1e17]'
              }`}
            >
              <FileScan className={`w-4 h-4 ${theme === 'light' ? 'text-amber-700' : 'text-[#f6d16f]'}`} />
              <span>{lang === 'bn' ? 'বাসের সাইনবোর্ড ও ভাড়ার তালিকা স্ক্যান' : 'Scan Bus Signboard OCR'}</span>
            </button>
          </nav>
        </div>

        {/* Footer info & language/theme toggle */}
        <div className={`pt-4 border-t space-y-3 ${
          theme === 'light' ? 'border-slate-200' : 'border-[#c69429]/30'
        }`}>
          {/* Theme Selector */}
          <div className="flex items-center justify-between px-1 text-xs">
            <span className={theme === 'light' ? 'text-slate-700 font-bold' : 'text-[#dfcfb2]'}>
              {lang === 'bn' ? 'থিম নির্বাচন' : 'Theme Mode'}
            </span>
            <div className="navbar-segmented-wrap">
              <button
                type="button"
                onClick={() => setTheme && setTheme('light')}
                className={`navbar-btn ${theme === 'light' ? 'navbar-btn-active-sun' : 'navbar-btn-inactive'}`}
              >
                <Sun className="w-3.5 h-3.5" />
                <span>{lang === 'bn' ? 'লাইট' : 'Light'}</span>
              </button>
              <button
                type="button"
                onClick={() => setTheme && setTheme('dark')}
                className={`navbar-btn ${theme === 'dark' ? 'navbar-btn-active-moon' : 'navbar-btn-inactive'}`}
              >
                <Moon className="w-3.5 h-3.5" />
                <span>{lang === 'bn' ? 'ডার্ক' : 'Dark'}</span>
              </button>
            </div>
          </div>

          {/* Language Selector */}
          <div className="flex items-center justify-between px-1 text-xs">
            <span className={theme === 'light' ? 'text-slate-700 font-bold' : 'text-[#dfcfb2]'}>
              {lang === 'bn' ? 'ভাষা নির্বাচন' : 'Language'}
            </span>
            <div className="navbar-segmented-wrap">
              <button
                type="button"
                onClick={() => setLang && setLang('bn')}
                className={`navbar-btn ${lang === 'bn' ? 'navbar-btn-active-bn' : 'navbar-btn-inactive'}`}
              >
                বাংলা
              </button>
              <button
                type="button"
                onClick={() => setLang && setLang('en')}
                className={`navbar-btn ${lang === 'en' ? 'navbar-btn-active-en' : 'navbar-btn-inactive'}`}
              >
                English
              </button>
            </div>
          </div>

          <div className="text-[11px] text-[#8a7258] px-1 flex items-center gap-1.5 font-mono">
            <ShieldAlert className="w-3.5 h-3.5 text-[#c69429]" />
            <span>INIF 2026 Smart City Hackathon</span>
          </div>
        </div>
      </div>
    </div>
  );
}
